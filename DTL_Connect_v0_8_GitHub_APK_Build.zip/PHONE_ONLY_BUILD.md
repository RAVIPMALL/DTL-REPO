# Build DTL Connect v0.8 APK using only your phone

The project now contains a GitHub Actions workflow at:
`.github/workflows/android-apk.yml`

## Phone-only process

1. Create/sign in to a GitHub account in Chrome on your phone.
2. Create a new repository, e.g. `dtl-connect`.
3. Upload the contents of this project to that repository. The `android/` folder and `.github/` folder must be preserved.
4. Open the repository's **Actions** tab.
5. Select **Build DTL Connect APK**.
6. Tap **Run workflow**.
7. Wait for the build to finish.
8. Open the completed workflow run and download the artifact named:
   `DTL-Connect-v0.8-debug`
9. Extract the downloaded artifact and install `app-debug.apk` on your Android phone.

## Demo access

Employee:
demo.employee
DTL@Demo2026

Admin:
demo.admin
DTL@Admin2026

These are synthetic UAT credentials and must be disabled before production.

## Important

This is a DEBUG/UAT APK build, not a production-signed APK. For a real DTL deployment, use a DTL-controlled signing key, production identity/MFA, backend environment, secure document storage and security/UAT approval.
